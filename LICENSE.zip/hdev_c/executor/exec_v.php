<?php  
//sleep(5);
	if ($_POST) {
		if (!empty($_POST['ref'])) { 
			$rasms_stc = new hdev_auth_service('',trim($_POST['ref']));
			if ($rasms_stc->access()) {
				/// access granted 
			}else{
			  $rasms_stc->error('danger');
			}

  		switch ($_POST['ref']) {
  			case 'login':
  				
				if (!empty($_POST['usn']) && !empty($_POST['psw'])) {
					hdev_v::login($_POST["usn"],$_POST['psw']);
				}else{
					hdev_note::message(hdev_lang::on("validation","log_fair"));
	        		//hdev_note::redirect(hdev_url::get_url_host()."/h/login");
				}
 
			break;
			case 'location_select':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['cover']);
				if (isset($_POST['type']) && !empty($_POST['type'])) {
      				switch ($_POST['type']) {
      					case 'district':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						echo hdev_data::locations("district",$province);
      					break;
      					case 'sector':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
      						echo hdev_data::locations("sector",$province,$district);
      					break;
						case 'cell':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;
      						echo hdev_data::locations("cell",$province,$district,$sector);
      					break;
      					case 'village':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;  
      						$cell = (isset($_POST['cell'])) ? $_POST['cell'] : "" ;
      						echo hdev_data::locations("village",$province,$district,$sector,$cell);
      					break;
      					default:
      						echo "<option>Try again!</option>";
      					break;
      				}
      				
				}else{
					echo "all fields are required";
				}
			break;
			case 'request_child':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['cr_num']) && !empty($_POST['cr_desc'])) {

					$cr_num = $_POST['cr_num'];
					$cr_desc = $_POST['cr_desc'];
					$sp_id = hdev_log::uid();
					$rt = new hdev_db();
      				$tab = $rt->table("center"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("INSERT INTO `child_request` (`cr_id`, `sp_id`, `cr_num`, `cr_desc`, `cr_status`, `cr_reg_date`) VALUES (NULL, :sp_id, :cr_num, :cr_desc, '1', current_timestamp())",[[':sp_id',$sp_id],[':cr_num',$cr_num],[':cr_desc',$cr_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Your Children request was received you can now wait for confirmation",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Your Children request was received you can now wait for confirmation");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			case 'center_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['cn_name']) && !empty($_POST['cn_location']) && !empty($_POST['cn_tel']) && !empty($_POST['cn_username']) && !empty($_POST['cn_password'])) {

					$cn_name = $_POST['cn_name'];
					$cn_location = $_POST['cn_location'];
					$cn_tel = $_POST['cn_tel'];
					$cn_username = $_POST['cn_username'];
					$cn_password = $_POST['cn_password'];
					$cn_password = hdev_data::password_enc($cn_password);
					$rt = new hdev_db();
      				$tab = $rt->table("center"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`cn_id`, `cn_name`, `cn_location`, `cn_username`, `cn_tel`, `cn_password`, `cn_status`, `cn_reg_date`) VALUES (NULL, :cn_name, :cn_location, :cn_username, :cn_tel, :cn_password, '1', current_timestamp())",[[':cn_name',$cn_name],[':cn_location',$cn_location],[':cn_username',$cn_username],[':cn_tel',$cn_tel],[':cn_password',$cn_password]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New collection ceneter Registered",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New collection ceneter Registered");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			case 'edit_center':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['cn_name']) && !empty($_POST['cn_location']) && !empty($_POST['cn_tel']) && !empty($_POST['cn_username']) && !empty($_POST['cn_id'])) {

					$cn_name = $_POST['cn_name'];
					$cn_location = $_POST['cn_location'];
					$cn_tel = $_POST['cn_tel'];
					$cn_username = $_POST['cn_username'];
					$cn_id = $_POST['cn_id'];
					$rt = new hdev_db();
      				$tab = $rt->table("center"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("UPDATE `$tab` SET `cn_name` = :cn_name, `cn_location` = :cn_location, `cn_username` = :cn_username, `cn_tel` = :cn_tel WHERE `cn_id` = :cn_id",[[':cn_name',$cn_name],[':cn_location',$cn_location],[':cn_username',$cn_username],[':cn_tel',$cn_tel],[':cn_id',$cn_id]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("collection ceneter info updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("collection ceneter info updated");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'child_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['cn_id']) && !empty($_POST['ch_name']) && !empty($_POST['ch_nid']) && !empty($_POST['ch_sex']) && !empty($_POST['ch_born']) && !empty($_POST['ch_desc'])) {

					$cn_id = $_POST['cn_id'];
					$ch_name = $_POST['ch_name'];
					$ch_nid = $_POST['ch_nid'];
					$ch_sex = $_POST['ch_sex'];
					$ch_born = $_POST['ch_born'];
					$ch_desc = $_POST['ch_desc'];

					$rt = new hdev_db();
      				$tab = $rt->table("child"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("INSERT INTO `child` (`ch_id`, `cn_id`, `ch_nid`, `ch_name`, `ch_sex`, `ch_born`, `ch_desc`, `ch_status`, `ch_reg_date`) VALUES (NULL, :cn_id, :ch_nid, :ch_name, :ch_sex, :ch_born, :ch_desc, '1', current_timestamp())",[[':cn_id',$cn_id],[':ch_nid',$ch_nid],[':ch_name',$ch_name],[':ch_sex',$ch_sex],[':ch_born',$ch_born],[':ch_desc',$ch_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New Child Registered",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New Child Registered");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;		
			case 'edit_child':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['cn_id']) && !empty($_POST['ch_name']) && !empty($_POST['ch_nid']) && !empty($_POST['ch_sex']) && !empty($_POST['ch_born']) && !empty($_POST['ch_desc']) && !empty($_POST['ch_id'])) {

					$cn_id = $_POST['cn_id'];
					$ch_name = $_POST['ch_name'];
					$ch_nid = $_POST['ch_nid'];
					$ch_sex = $_POST['ch_sex'];
					$ch_born = $_POST['ch_born'];
					$ch_desc = $_POST['ch_desc'];
					$ch_id = $_POST['ch_id'];
					$rt = new hdev_db();
      				$tab = $rt->table("child"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("UPDATE `child` SET `cn_id` = :cn_id, `ch_nid` = :ch_nid, `ch_name` = :ch_name, `ch_sex` = :ch_sex, `ch_born` = :ch_born, `ch_desc` = :ch_desc WHERE `ch_id` = :ch_id",[[':cn_id',$cn_id],[':ch_nid',$ch_nid],[':ch_name',$ch_name],[':ch_sex',$ch_sex],[':ch_born',$ch_born],[':ch_desc',$ch_desc],[":ch_id",$ch_id]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Child info updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Child info updated");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;				
			case 'sponsor_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['sp_type']) && !empty($_POST['sp_nid']) && !empty($_POST['sp_name']) && !empty($_POST['sp_tel']) && !empty($_POST['sp_username']) && !empty($_POST['sp_password']) && !empty($_POST['sp_desc']) && !empty($_POST['sp_location'])) {

					$sp_type = $_POST['sp_type'];
					$sp_nid = $_POST['sp_nid'];
					$sp_name = $_POST['sp_name'];
					$sp_tel = $_POST['sp_tel'];
					$sp_username = $_POST['sp_username'];
					$sp_password = $_POST['sp_password'];
					$pass = $sp_password;
					$sp_password = hdev_data::password_enc($sp_password);
					$sp_desc = $_POST['sp_desc'];
					$sp_location = $_POST['sp_location'];
					$state = (hdev_log::fid() == "guest") ? "2" : "1" ;

					$rt = new hdev_db();
      				$tab = $rt->table("sponsor"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`sp_id`, `sp_type`, `sp_name`, `sp_nid`, `sp_tel`, `sp_username`, `sp_password`,`sp_location`, `sp_desc`, `sp_status`, `sp_reg_date`) VALUES (NULL, :sp_type, :sp_name, :sp_nid, :sp_tel, :sp_username, :sp_password, :sp_location,:sp_desc, :state, current_timestamp())",[[':sp_type',$sp_type],[':sp_nid',$sp_nid],[':sp_name',$sp_name],[':sp_tel',$sp_tel],[':sp_username',$sp_username],[':sp_password',$sp_password],[':sp_desc',$sp_desc],[':sp_location',$sp_location],[":state",$state]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if ($state == "2") {
      						hdev_note::live_sms($sp_tel,"Dear ".$sp_name."! your sponsorship application was submited please wait for confirmation to be able to login. Thank You!");hdev_note::success("New sponsor Registration completed");
      					}else{
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::live_sms($sp_tel,"Dear ".$sp_name."! you are now registered as sponsor you can now login with username: [".$sp_username."] and password: [".$pass."] at ".hdev_url::menu('login')." . Thank You!");
      						hdev_note::success("New sponsor Registration completed",$_POST['mod_close']);hdev_note::success("New sponsor Registration completed");
      					}else{
      						hdev_note::live_sms($sp_tel,"Dear ".$sp_name."! you are now registered as sponsor you can now login with username: [".$sp_username."] and password: [".$pass."] at ".hdev_url::menu('login')." . Thank You!");
      						hdev_note::success("New sponsor Registration completed");
      					}
      						
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;		
			case 'edit_sponsor':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['sp_type']) && !empty($_POST['sp_nid']) && !empty($_POST['sp_name']) && !empty($_POST['sp_tel']) && !empty($_POST['sp_username']) && !empty($_POST['sp_id']) && !empty($_POST['sp_desc']) && !empty($_POST['sp_location'])) {

					$sp_type = $_POST['sp_type'];
					$sp_nid = $_POST['sp_nid'];
					$sp_name = $_POST['sp_name'];
					$sp_tel = $_POST['sp_tel'];
					$sp_username = $_POST['sp_username'];
					$sp_id = $_POST['sp_id'];
					$sp_desc = $_POST['sp_desc'];
					$sp_location = $_POST['sp_location'];

					$rt = new hdev_db();
      				$tab = $rt->table("sponsor"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("UPDATE `$tab` SET `sp_type` = :sp_type, `sp_name` = :sp_name, `sp_nid` = :sp_nid, `sp_tel` = :sp_tel, `sp_username` = :sp_username, `sp_location` = :sp_location, `sp_desc` = :sp_desc WHERE `sp_id` = :sp_id",[[':sp_type',$sp_type],[':sp_nid',$sp_nid],[':sp_name',$sp_name],[':sp_tel',$sp_tel],[':sp_username',$sp_username],[':sp_id',$sp_id],[':sp_desc',$sp_desc],[':sp_location',$sp_location]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Sponsor info updated Successfull",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Sponsor info updated Successfull");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;											
			case 'change_user_pwd':
				$csrf = new CSRF_Protect(); 
    			$csrf->verifyRequest();
				if (!empty($_POST['id']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
					$id = $_POST['id'];
					$new_password = $_POST['new_password'];
					$confirm_password = $_POST['confirm_password'];

					if ($new_password != $confirm_password) {
						exit("Two Passwords do not match!");
					}

					$password = hdev_data::password_enc($new_password);

					$sc_id = hdev_log::school_id();
					$pwd_changer = hdev_log::uid();
					$pwd_changer_school = hdev_data::get_user("data",$pwd_changer)['school'];
					$sc_code = hdev_data::get_school($sc_id,['data'])['year_1'];
					$pwd_changer_ref = hdev_data::get_user("data",$id)['school'];

					$user = hdev_data::get_user("user",$id);
					if ($id == $pwd_changer) {
						exit("You can't change your password on this page; please use My Profile page to do this!");
					}

					if ($pwd_changer_school != $pwd_changer_ref || $pwd_changer_school != $sc_code) {
						exit("you are not allowed to change this user password");
					}

					

					$rt = new hdev_db();
      				$tab = $rt->table("user"); 

      				$ck = $rt->insert("UPDATE $tab SET `password` = :pwd WHERE `id` = :id AND school = :sc ",[[':pwd',$password],[':sc',$sc_code],[':id',$id]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Password for User: \" <u>".$user."</u> \" changed",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Password for User: \" <u>".$user."</u> \" changed");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}

				}else{
					echo "all fields are required";
				}
			break;
			case 'user_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (isset($_POST['name']) && isset($_POST['username']) && isset($_POST['tel'])) {
					$name = $_POST['name'];
					$username = $_POST['username'];
					$tel = $_POST['tel'];
      				if (hdev_data::phone_valid($tel)) {
      					exit(hdev_data::phone_valid($tel));
      				}
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
						$tab = $rt->table("police");
		      				$ck = $rt->insert("UPDATE $tab SET `p_name` = :name, `p_tel` = :tel, `p_username` = :username WHERE `p_id` = :id",[[":id",$id],[':name',$name],[":username",$username],[":tel",$tel]]);
						break;
						case 'sponsor':
						$tab = $rt->table("sponsor");
		      				$ck = $rt->insert("UPDATE $tab SET `sp_name` = :name, `sp_tel` = :tel, `sp_username` = :username WHERE `sp_id` = :id",[[":id",$id],[':name',$name],[":username",$username],[":tel",$tel]]);
						break;				
						default:
							exit(hdev_lang::on("validation","not_change_info"));
							break;
					}

      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success(hdev_lang::on("validation","info_changed"),$_POST['mod_close']);
      					}else{
      						hdev_note::success(hdev_lang::on("validation","info_changed"));
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'self_change_user_pwd':
				$csrf = new CSRF_Protect(); 
    			$csrf->verifyRequest();
				if (!empty($_POST['old_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
					$id = hdev_log::uid();
					$new_password = $_POST['new_password'];
					$confirm_password = $_POST['confirm_password'];
					$old_password = $_POST['old_password'];

					if ($new_password != $confirm_password) {
						exit(hdev_lang::on("validation","passwords_not_match"));
					}

					$password = hdev_data::password_enc($new_password);
					$old_password_hash = hdev_data::password_enc($old_password);
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
							$tab = $rt->table("police");
							$old_password_db = hdev_data::get_admin(hdev_log::uid(),['data'])["p_password"];
							$user = hdev_data::get_admin(hdev_log::uid(),['data'])["p_name"];
							if ($old_password_hash != $old_password_db) {
								exit(hdev_lang::on("validation","incorrect_current_password"));
							}
      						$ck = $rt->insert("UPDATE $tab SET `p_password` = :pwd WHERE `p_id` = :id",[[':pwd',$password],[':id',$id]]);
						break;
						case 'sponsor':
							$tab = $rt->table("sponsor");
							$old_password_db = hdev_data::sponsor(hdev_log::uid(),['data'])["sp_password"];
							$user = hdev_data::sponsor(hdev_log::uid(),['data'])["sp_name"];
							if ($old_password_hash != $old_password_db) {
								exit(hdev_lang::on("validation","incorrect_current_password"));
							}
      						$ck = $rt->insert("UPDATE $tab SET `sp_password` = :pwd WHERE `sp_id` = :id",[[':pwd',$password],[':id',$id]]);
						break;		
						default:
							exit(hdev_lang::on("validation","not_change_password"));
							break;
					}
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success(hdev_lang::on("validation","password_changed").". User: \" <u>".$user."</u> \"",$_POST['mod_close']);
      					}else{
      						hdev_note::success(hdev_lang::on("validation","password_changed").". User: \" <u>".$user."</u> \"");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}

				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			default:
				echo "404! Sorry we can't see what you are looking for please refesh this page and try again.";
			break;
		}
		}
		//var_dump($_POST);
	}

 ?>