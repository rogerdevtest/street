 <?php
    //$langg = $_SESSION['lang'];
    //$lang = $_SESSION['exp']; 
    $menutop = array(
      "1" => array(
        "name" => hdev_lang::on("menu","home"),
        "trees" => "1",
        "icon" => "fa fa-home",
        "link" => "r...home"
      ),
      "2" => array(
        "name" => hdev_lang::on("menu","about"),
        "trees" => "1",
        "icon" => "fas fa-book",
        "link" => "r...about"
      ),
      "3" => array(
        "name" => hdev_lang::on("menu","contact"),
        "trees" => "1",
        "icon" => "fas fa-phone fa-3x",
        "link" => "r...contact"
      )
    );

  ?> 
<?php
    $menumask = array("hm", "prof", "center", "child","sponsor_ind","report");
    $menumain = array(
      "hm" => array(
        "name" => hdev_lang::on("menu","home"), 
        "trees" => "1",
        "icon" => "fas fa-home",
        "link" => "r...home",
        "power" => ""
      ),
      "prof" => array(
        "name" => hdev_lang::on("menu","profile")."^^".hdev_lang::on("menu","my_profile"),
        "trees" => "2",
        "icon" => " fa fa-user-cog  ^^  fas fa-user",
        "link" => "# ^^  r...profile",
        "power" => "no"
      ), 
      "child" => array(
        "name" => "Children"."^^"."Children Info"."^^"."Deleted Children ^^ Request Children ^^ Received Children requests ^^ Approved Request ^^ Rejected Requests",
        "trees" => "2",
        "icon" => " fa fa-user-cog  ^^  fas fa-user ^^  fas fa-user ^^ fa fa-users ^^ fa fa-users ^^ fa fa-check-circle ^^ fa fa-times-circle",
        "link" => "# ^^  child...reg ^^  child...delete ^^ request...child ^^ child...request ^^ child...approve ^^ child...reject",
        "power" => "no"
      ),  
      "center" => array(
        "name" => "Rehabilitation Centers"."^^"."Rehabilitation Centers Info"."^^"."Deleted Rehabilitation Centers",
        "trees" => "2",
        "icon" => " fa fa-user-cog  ^^  fas fa-user ^^  fas fa-user",
        "link" => "# ^^  center...reg ^^  center...deleted",
        "power" => "no"
      ),   
      "sponsor_ind" => array(
        "name" => "Sponsors"."^^"."Sponsors Info"."^^"."Deleted Sponsors ^^ Registration Requests ^^ Reject registration Requests",
        "trees" => "2",
        "icon" => " fa fa-user-cog  ^^  fas fa-user ^^  fas fa-trash ^^ fa fa-recycle ^^ fa fa-times-circle",
        "link" => "# ^^  sponsor...reg ^^  sponsor...deleted ^^  sponsor...approve ^^  sponsor...reject",
        "power" => "no"
      ),   
      "sponsor_comp" => array(
        "name" => "Company Sponsors"."^^"."Company Sponsor Info"."^^"."Deleted Company Sponsors",
        "trees" => "2",
        "icon" => " fa fa-user-cog  ^^  fas fa-user ^^  fas fa-user",
        "link" => "# ^^  r...profile/a/b/c ^^  r...profile/a/b/c",
        "power" => "no"
      ), 
      "report" => array(
        "name" => "Reports"."^^"."Children with sponsors ^^ My sponsored Children",
        "trees" => "2",
        "icon" => " fa fa-file  ^^  fa fa-file ^^ fa fa-file",
        "link" => "# ^^  sponsor...child ^^ my...child/".hdev_data::encd(hdev_log::uid())."/request",
        "power" => "no"
      ),       
    );
  ?>
    <nav class="main-header navbar navbar-expand navbar-dark navbar-dark text-sm">
    <div class="container">
      <a href="<?php echo hdev_url::get_url_host(); ?>" class="navbar-brand" align="center">
        <img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/rasms.ico'));?>" alt="<?php echo APP_NAME; ?> Logo" class="brand-image img-circle elevation-3"
             style="opacity: .8;height: auto;width: 2.1rem;">
        <span class="font-weight-light text-sm"><?php echo "<b>".APP_NAME."</b>"; ?></span>
      </a>
      <!-- Right navbar links -->
      <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
        <li class="nav-item">
              <?php
                if (hdev_log::loged()) {
              ?>
                <a class="nav-link ind" rel="external" onclick="logout('<?php echo hdev_url::menu('r/home'); ?>?logout=ok')" href="#" ext_link="ok">
                  <i class="fas fa-power-off" title="logout"></i>&nbsp;Logout
              <?php
                  //echo hdev_lang::on("menu","logout")."<b>&nbsp;(&nbsp;".hdev_data::active_user("username")."&nbsp;)</b>";
                }else{
              ?>
                  <a class="nav-link ind" rel="external" href="<?php echo hdev_url::menu('login'); ?>" ext_link="ok" >
                    <i class="fas fa-power-off" title=""></i>&nbsp;Logout
              <?php
                  //echo hdev_lang::on("menu","login");
                }
              ?>
            </a>
        </li> 
      </ul>
      </div>
  </nav>
  <!-- Navbar -->
<nav class="main-header navbar navbar-expand-md navbar-dark text-sm top_nav" id="of_head">
      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="<?php echo hdev_lang::on('menu','services'); ?>" title="<?php echo hdev_lang::on('menu','services'); ?>" id="mhead">
        <span class="navbar-toggler-icon"></span>
        Menu
      </button>
  <div class="collapse navbar-collapse order-3" id="navbarCollapse">
    <!-- Left navbar links --> 
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link navbar-toggler order-1" data-widget="pushmenu" href="#" role="button" data-toggle="collapse" aria-controls="navbarCollapse" aria-expanded="false"><i class="fas fa-bars"></i>&nbsp;<?php echo hdev_lang::on("menu","services") ?></a>
      </li>
      <li class="nav-item d-sm-inline-block">
        <a href="<?php echo hdev_url::menu("r/home") ?>" class="nav-link"><i class="fas fa-home"></i>&nbsp;<?php echo hdev_lang::on("menu","home") ?></a>
      </li>
      <?php 
        if (hdev_log::cart("check")) {
       ?>
      <li class="nav-item d-sm-inline-block">
        <a href="<?php echo hdev_url::menu("list/transfer") ?>" class="nav-link"><i class="fas fa-users"></i>&nbsp;List of Children Available for transfering</a>
      </li> 
      <?php } ?>   
      <!--<div id="google_translate_element" class="nav-item bg-white"></div>-->
    </ul>
  </div>

    <!-- Right navbar links -->
    <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
      <li class="nav-item d-sm-inline-block">
        <div class="nav-link" id="menu_loader"></div>
        <!--loader-->
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>

    </ul>
  </nav>
  <!-- /.navbar --> 

<?php if (hdev_log::loged()): ?>
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar main-sidebar-custom sidebar-dark-primary elevation-4" id="left_nav">
    <!-- Brand Logo -->
    <div class="brand-link row" style="display: inline-flex;">
      <span style="width: 95%;">
        <a href="index3.html" class="text-light">
          <img src="<?php echo hdev_url::menu('dist/img/rasms.ico'); ?>" alt="<?php echo APP_NAME;?>" class="brand-image img-circle elevation-3" style="opacity: .8">
          <span class="brand-text font-weight-light"><?php echo hdev_data::abbr(constant("APP_NAME")); ?></span>
        </a>
      </span>
      <span class="text-md" align="right" style="width: 5%;">
         <a class="text-light close_nv" data-widget="pushmenu" href="#" role="button"><i class="fas fa-times"></i></a>
         <a class="text-light close_nv2" data-widget="pushmenu" href="#" role="button" style="display: none;"><i class="fas fa-bars"></i></a>
      </span>
    </div>
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <span class="fa fa-user-circle fa-2x img-circle elevation-2"></span>
        </div>
        <div class="info text-nowrap">
          <a ext_link="ok" class="d-sm-inline-block"><?php echo hdev_data::active_user("name"); ?></a>
        </div>
      </div>
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-child-indent nav-flat" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <?php 
            for ($i=0; $i < count($menumask); $i++) { 
              $mmenu = $menumask;
              hdevmenu::mainmenu($menumain[$mmenu[$i]]['trees'],$menumain[$mmenu[$i]]['name'],$menumain[$mmenu[$i]]['link'],$menumain[$mmenu[$i]]['icon'],$menumain[$mmenu[$i]]['power']);
            }
          ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->

    <div class="sidebar-custom">
      <?php 
        if (hdev_log::loged()) {
      ?>
        <span class="bg-secondary" align="center">
          <i><span href="#" class="hide-on-collapse text-xs">Working as :</span> <?php echo hdev_data::active_user("fid") ?></i>        
        </span>
      <?php
        }else{
      ?>
        <span class="bg-secondary" align="center">
          <i><span href="#" class="hide-on-collapse text-xs">Working as :</span> Guest</i>        
        </span>

      <?php
        }
      ?>
      
    </div>
    <!-- /.sidebar-custom -->
  </aside>
<?php endif ?>
