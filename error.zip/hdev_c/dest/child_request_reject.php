<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>rejected Children request Info</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('request_child')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i>Submit New Children request</button>&nbsp;
                  <?php endif ?>
                </div>
                
                  <table data-order='[[ 0, "desc" ]]' id="rasms_all_tables" class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Sponsor Reg No.</th>
                      <th>Sponsor Type</th>
                      <th>Sponsor name</th>
                      <th>Sponsor NID/TIN</th>
                      <th>Number of children rquested</th>
                      <th>Number of children Received</th>
                      <th>Reg. Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::child_request("",["reject"]);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:approve_request;id:".$group['cr_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);  
                      $build3 = "ref:reject_request;id:".$group['cr_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject2 = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build3); 

                      $sponsor = hdev_data::sponsor($group['sp_id'],["data"]);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["cr_id"]; ?>
                      </td>
                      <td class="table-plus">
                        <?php echo $group["sp_id"]; ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo hdev_data::sponsor_type($sponsor["sp_type"]); ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo $sponsor["sp_name"]; ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo $sponsor["sp_nid"]; ?>
                      </td>                                          
                      <td>
                        <?php echo $group['cr_num']; ?> Children
                      </td>
                      <td>
                        0
                      </td>
                      <td>
                        <?php echo $group['cr_reg_date']; ?>
                      </td>                
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>