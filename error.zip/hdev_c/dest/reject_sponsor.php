<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Rejected Sponsor Registration requests</h5>
              </div>
              <div class="card-body table-responsive p-2">
                
                  <table data-order='[[ 0, "desc" ]]' id="rasms_all_tables" class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>type</th>
                      <th>Name</th>
                      <th>ID/TIN</th>
                      <th>Tel</th>
                      <th>Username</th>
                      <th>Location</th>
                      <th>Description</th>
                      <th>Reg. Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::sponsor("",['reject']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:approve_sponsor;id:".$group['sp_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);   

                      $build3 = "ref:reject_sponsor;id:".$group['sp_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject2 = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build3);                   

                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["sp_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::sponsor_type($group["sp_type"]); ?>
                      </td>
                      <td>
                        <?php echo $group['sp_name']; ?>
                      </td>
                      <td>
                        <?php echo $group['sp_nid']; ?>
                      </td>
                      <td>
                        <?php echo $group['sp_tel'] ?>
                      </td>
                      <td>
                        <?php echo $group['sp_username']; ?>
                      </td> 
                      <td>
                        <?php echo $group['sp_location'] ?>
                      </td>
                      <td>
                        <?php echo $group['sp_desc'] ?>
                      </td>                                         
                      <td>
                        <?php echo $group['sp_reg_date']; ?>
                      </td>                  
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>