<?php 
//exit($data);
	if (isset($data) && !empty($data)) {}else{exit('validation failed');}
	$store = explode(';', $data);
	$HDEV =array();
	if (is_array($store) && count($store)>0) {
		foreach ($store as $stt) {
			$store2 = explode(':', $stt);
			if (is_array($store2) && count($store2) == 2) {
				$HDEV[$store2[0]]=$store2[1];
			}
		}
		
	}else{exit('validation failed');}
	
	if (is_array($HDEV) && count($HDEV) > 0 && isset($HDEV['ref'])) {
	}else{
		exit("validation Failed!");
	}
	$rasms_stc = new hdev_auth_service('',trim($HDEV['ref']));
	if ($rasms_stc->access()) {
		/// access granted 
	}else{
	  $disp = $rasms_stc->error('alert');
	  $HDEV['ref'] = "";

	  $from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
	  hdev_note::message($disp);
	  hdev_note::redirect($from);
	  exit();
	}
	$csrf = new CSRF_Protect();
  	$csrf->verifyRequest($HDEV['app']);
	switch ($HDEV['ref']) {	
		case 'delete_sponsor':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("sponsor");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `sp_status` = :status WHERE `sp_id` = :id",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Sponsor deleted successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Sponsor deleted successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;	
		case 'recover_sponsor':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("sponsor");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `sp_status` = :status WHERE `sp_id` = :id",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Sponsor recovered successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Sponsor recovered successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;	
		case 'approve_sponsor':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("sponsor");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `sp_status` = :status WHERE `sp_id` = :id",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				$sponsor = hdev_data::sponsor($id,["data"]);
      				$tel = $sponsor['sp_tel'];
      				hdev_note::live_sms($tel,"Dear ".$sponsor['sp_name']."! Your account creation has beeen approved you can now log in "." with username: [".$sponsor['sp_username']."]. Thank you!");
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Sponsor account approved successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Sponsor account approved successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;
		case 'reject_sponsor':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("sponsor");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `sp_status` = :status WHERE `sp_id` = :id",[[":id",$id],[":status",'3']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				$sponsor = hdev_data::sponsor($id,["data"]);
      				$tel = $sponsor['sp_tel'];
      				hdev_note::live_sms($tel,"Dear ".$sponsor['sp_name']."! Your account creation has beeen Rejected you can call the nearest police office to know why. Thank you!");
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Sponsor account rejected successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Sponsor account rejected successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;		
		case 'approve_request':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child_request");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `cr_status` = :status WHERE `cr_id` = :id",[[":id",$id],[":status",'2']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				$spo_id = hdev_data::child_request($id,["data"])['sp_id'];
      				$sponsor = hdev_data::sponsor($spo_id,["data"]);
      				$tel = $sponsor['sp_tel'];
      				hdev_note::live_sms($tel,"Dear ".$sponsor['sp_name']."! Your children sponsorship was approved and you will receive a call from a police station to know more info. Thank You!");
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Child request approved successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Child request approved successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;
		case 'reject_request':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child_request");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `cr_status` = :status WHERE `cr_id` = :id",[[":id",$id],[":status",'3']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				$sponsor = hdev_data::sponsor($id,["data"]);
      				$tel = $sponsor['sp_tel'];
      				hdev_note::live_sms($tel,"Dear ".$sponsor['sp_name']."! Your children sponsorship was rejected, please call nearest police station to know more info. Thank you!");
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Sponsor account rejected successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Sponsor account rejected successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;
		case 'pr_grant_child':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				if (hdev_log::cart_init("init",$id)) {
					hdev_note::message("Children granting initialized, please select children to continue!");
					hdev_note::redirect(hdev_url::menu("list/transfer"));
				}else{
					echo hdev_lang::on("validation","error_try_again");
				}
			}
		break;
		case 'delete_sponsored':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child_transfer");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `ct_status` = :status,`ct_can_date` = current_timestamp() WHERE `ct_id` = :id",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				$sp_id = hdev_data::child_transfer($id,['data'])['sp_id'];
      				
      				$sponsor = hdev_data::sponsor($sp_id,["data"]);
      				$tel = $sponsor['sp_tel'];
      				hdev_note::live_sms($tel,"Dear ".$sponsor['sp_name']." one of the children has been removed from your sponsored children please vist a nearest police to find more info.thanks!!");
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("child sponsorship removal completed".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("child sponsorship removal completed".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;
		case 'transfer_child':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child_transfer");
      			if (!hdev_log::cart("check")) {
      				exit("Please select chird request record first");
      				if (!is_numeric(hdev_log::cart("val"))) {
      					hdev_log::cart_init("destroy");
      					exit("Please select chird request record first");
      				}
      			}
      			$cr_id = hdev_log::cart("val");
      			$request_data = hdev_data::child_request($cr_id,['data']);

      			$sponsor = $request_data['sp_id'];

      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("INSERT INTO `child_transfer` (`ct_id`, `cr_id`, `ch_id`, `sp_id`, `p_id`, `ct_status`, `ct_reg_date`, `ct_can_date`) VALUES (NULL, :cr_id, :id, :sponsor, :user, '1', current_timestamp(), NULL)",[[":id",$id],[":cr_id",$cr_id],[":sponsor",$sponsor],[":user",$user]]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Child transfered to current sponsor reg_no: ".$sponsor." ".', <u>with request id: '.$cr_id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Child transfered to current sponsor reg_no: ".$sponsor." ".', <u>with request id: '.$cr_id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;					
		case 'delete_child':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `ch_status` = :status WHERE `ch_id` = :id",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Child deleted successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Child deleted successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;	
		case 'recover_child':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("child");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `ch_status` = :status WHERE `ch_id` = :id",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Child recovered successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Child recovered successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;	
		case 'delete_center':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("center");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `cn_status` = :status WHERE `cn_id` = :id",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Collection center deleted successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Collection center deleted successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;	
		case 'recover_center':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("center");
      			$user = hdev_log::uid();
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `cn_status` = :status WHERE `cn_id` = :id",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success("Collection center recovered successfull".', <u>Reg No: '.$id.'</u>',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success("Collection center recovered successfull".', <u>Reg No: '.$id.'</u>');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo hdev_lang::on("validation","error_try_again");
      			}
			}
		break;						
		default:
			echo "we cannot handle what you requested try again later";
			//hdev_note::message('we cannot handle what you requested try again later');
			//hdev_note::redirect(hdev_url::menu(''));
		break;
	}

 ?>