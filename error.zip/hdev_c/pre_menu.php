<div id="app_menu">
	<!--menu-->
</div>
<div id="app_body">