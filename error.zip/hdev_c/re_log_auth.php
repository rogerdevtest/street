<div class="box">
  <!--<div align="center">
    <img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/rasms2.ico'));?>" style="height: 138px;width: 138px;">
  </div>-->
  
  <h3><?php echo hdev_lang::on('form','login_at'); ?> <br> <?php echo APP_NAME ?></h3>
  
  <form id="login_form" class="form-signin" method="POST" onsubmit="login(); return false;">
    <input type="hidden" name="ref" value="login">   
    <div class="inputBox">
      <input type="text" name="usn" required />
      <label>Email/username</label>
    </div>
    <div class="inputBox">
      <input type="password" name="psw" required />
      <label><?php echo hdev_lang::on('form','password'); ?></label>
    </div>
    <div class="wait" align="center" style="display: none;color: #ffffff;">
        <span><img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/loading2.gif'));?>" alt="" /></span>
        <br>
        <i><?php echo hdev_lang::on('validation','processing'); ?>!!!</i>
    </div>
    <div id="fsave">
      <button type="submit" class="btn bg-gradient-primary btn-block" title="Click to Login" name="ok" value="Submit"><i class="fa fa-unlock"></i> <?php echo hdev_lang::on('form','login'); ?></button>
    </div>
    <br>
    <div class="input-group input-group-sm">
        <button type="button" class="btn btn-warning mb-2 btn-block dropdown-toggle" data-toggle="dropdown">
          <i class="fas fa-user-plus"></i>&nbsp; Create Account
        </button>
        <ul class="dropdown-menu">
          <li class="dropdown-item"><button type="button" class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> As Sponsor</button></li>
          <li class="dropdown-item"><a href="#" class="dropdown-item" ext_link="ok" onclick="alert('comming soon');">As Parent</a></li>
        </ul>
    </div>
    <i style="color: #fff;display: none;">&copy;- <?php echo date("Y"); ?> - <a href="https://www.facebook.com/roger.hrw/" target="_blank" style="background-color: transparent!important;">  <?php echo APP_PROGRAMMER["name"] ?> </a> --- All rights reserved</i>
  </form>
</div>






<?php if (hdev_data::service('sponsor_reg')): ?>
<div class="modal fade modal-reg"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">New Sponsor self Registration</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="sponsor_reg">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="sponsor_reg">   
            <div class="form-group">
              <label for="sp_type">
                Sponsor Type :
              </label>
              <div class="input-group mb-3">
                <select type="text" class="form-control" name="sp_type" id="sp_type">
                  <option value="">Select Sponsor type</option>
                  <option value="1">Individual sponsor</option>
                  <option value="2">Company Sponsor</option>
                </select>
              </div>
            </div>                    
            <div class="form-group">
              <label for="sp_nid">
                Sponsor Id/TIN :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_nid" id="sp_nid" placeholder="Sponsor ID">
              </div>
            </div>
            <div class="form-group">
              <label for="sp_name">
                Sponsor name :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_name" id="sp_name" placeholder="Sponsor name">
              </div>
            </div> 
            <div class="form-group">
              <label for="sp_tel">
                Sponsor Tel :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_tel" id="sp_tel" placeholder="Sponsor Tel">
              </div>
            </div>
            <div class="form-group">
              <label for="sp_username">
                Sponsor Username :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_username" id="sp_username" placeholder="Sponsor Username">
              </div>
            </div> 
            <div class="form-group">
              <label for="sp_password">
                Sponsor Password :
              </label>
              <div class="input-group mb-3">
                <input type="password" class="form-control" name="sp_password" id="sp_password" placeholder="Password">
              </div>
            </div>  
            <div class="form-group">
              <label for="sp_location">
                Sponsor Location :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="sp_location" id="sp_location" placeholder="Location"></textarea>
              </div>
            </div>                                      
            <div class="form-group">
              <label for="sp_desc">
                Sponsor Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="sp_desc" id="sp_desc" placeholder="Sponsor Description"></textarea>
              </div>
            </div>      
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="sponsor_reg_btn" onclick="fm_submit('sponsor_reg_btn','sponsor_reg');"><i class="fa fa-save"></i> Submit sponsor registration request</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>