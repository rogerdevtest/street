<?php  
	define("APP_NAME", "Needs based street children M. S.");
	define('APP_MASK', 'Needs based street children M. S.');
	define("district", "Kicukiro District");
	define('tel', '0788');
	define('currency', 'Frw');
	define('working_dev','prod');//prod in production
	define('type', 'secure');//secure in production

	define('APP_PREFIX', 'HRA-pay');
	define('SMS_SENDER', 'NBSCMS');
	define('SMS_USERNAME', 'aline23');
	define('SMS_PASSWORD', 'aline23@2022');
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'Aline','email'=>'igiranezaaline1999@gmail.com']);
	define('APP_SQLITE_DB',"hdev_cop");


	/*define('dbhost',"localhost");
	define('db',"hdev_child");
	define('db_preview',"hdev_child");
	define('dbpass_preview', '');
	define('dbusr_preview', 'root');	
	define('dbpass', '');
	define('dbusr', 'root');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');*/

	define('dbhost',"bdoszrh0bwihnaumkdii-mysql.services.clever-cloud.com");
	define('db',"bdoszrh0bwihnaumkdii");
	define('db_preview',"bdoszrh0bwihnaumkdii");
	define('dbpass_preview', 'ZabqHzNsZRjCmganLYZ');
	define('dbusr_preview', 'u2to1pnzzs3b4qlp');	
	define('dbpass', 'ZabqHzNsZRjCmganLYZ');
	define('dbusr', 'u2to1pnzzs3b4qlp');
	define('dbport', '21219');
	define('dbport_preview', '21219');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');

	define('school_code', 'rasms_mtvet');
	//auth check 
	define("roger_draft", "hdev_c3538TVVTQU1WVSBUVkVUIFNDSE9PTA==");
	define('ad_us_pw', "hdev_79b11Li4uUk9HLi4=");
	//error_reporting(0);
 ?>