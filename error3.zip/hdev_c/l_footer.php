  </div>
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo hdev_url::menu('plugins/jquery/jquery.min.js');?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo hdev_url::menu('plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo hdev_url::menu('dist/js/adminlte.min.js');?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo hdev_url::menu('plugins/sweetalert2/sweetalert2.min.js');?>"></script>
<!-- font awesome -->
<!-- Preloader -->
  <script type="text/javascript">
    <?php if (constant('type') == 'secure'): ?>
     if (location.protocol !== 'https:') {
          location.replace(`https:${location.href.substring(location.protocol.length)}`);
      } 
    <?php endif ?>
  </script>
<script type="text/javascript">
  //<![CDATA[
    $(window).on('load', function() { // makes sure the whole site is loaded 
      $('#status').fadeOut(); // will first fade out the loading animation 
            $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
            $('body').delay(350).css({'overflow':'visible'});
    })
  //]]>
</script> 
<script type="text/javascript">
    function id_validator(val_text='',input_icon='',message_box='',sub_btn='') {

    if (val_text.length != 16) {
      errors = "Id must be 16 digits";
      var a = '<span class="text-danger">'+errors+'</span>';
      $(sub_btn).hide();
      $(message_box).html(a);
      $(input_icon).html('<span class="fa fa-times-circle text-danger"></span>');
    }else{
      $(sub_btn).show();
      $(message_box).html('');
      $(input_icon).html('<span class="fa fa-check-circle text-success"></span>');
    }
  }
    function attach(aa='') {
      window.location.reload();
    }
    var $load_status= '<span><i class="fa fa-spinner fa-spin"></i></span><i>&nbsp;&nbsp;wait...!!!</i>';
    function fm_submit(btn_ck,fm_ck,url_action='') {
      //alert('hello');
        var formData = jQuery('#'+fm_ck).serialize();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.wait').html($load_status);
                $('#'+btn_ck).hide();
               },
              success:function(html){
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#'+btn_ck).show();
                    window.location.reload();
                  }, 4000);
              },
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                $('#'+btn_ck).show();
              }
            });
    }
    function login() {
      //alert('helloooooo');
          const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: fsave,
          timer: 3000
        });
        var formData = jQuery('#login_form').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave").hide();
            $(".wait").show();
           },
          success:function(html){
            if (html == 'ok'){
              Toast.fire({
                type: 'success',
                title: '<?php echo hdev_lang::on("validation",'signedin'); ?>'
              });
              var delay = 1000;
              setTimeout(function(){
                 window.location.href='<?php echo hdev_url::menu("r/home");?>';
              }, delay);
            }else
            {
            //alert(html);
              Toast.fire({
                type: 'error',
                title: '<?php echo hdev_lang::on("validation",'log_fair'); ?>'
              });
              $(".wait").hide();
              $("#fsave").show();
            }
          },
          complete:function(html){
            // Hide image container
           setTimeout(function(){
              //$("#fsave").show();
              $(".wait").hide();
            }, 3000);
           }
        });
    } 
</script>
</body>
</html>
