<?php
if (!function_exists("hdev_vd")) {
  function hdev_vd()
  {
    //default validation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'exec_v.php';
    include $regd;
  }
}
if (!function_exists("mini_loader")) {
  function mini_loader()
  {
    //default mini navigation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'loader.php';
    return $regd;
  }
}
if (!function_exists("get_menu")) {
  function get_menu()
  {
    //default mini navigation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'menu.php';
    return $regd;
  }
}
if (!function_exists("get_home")) {
  function get_home()
  {
    $home = "hdev_c/home";
    if (hdev_log::loged()) {
      switch (hdev_log::fid()) {
        case 'member':
          $home = "hdev_c/member_home";
          break;
        
        default:
          $home = "hdev_c/home";
          break;
      }
    }
    return $home;
  }
}
// Include router class 
$regd = getcwd().DIRECTORY_SEPARATOR."hdev_c".DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR."hdev_parse.php";
include $regd;

$valid = array('login_i','up');
foreach ($valid as $vd) {
  hdev_route::add('/'.$vd, function() {
    hdev_vd();
    exit();
  });
} 


hdev_route::add('/app/report/(.*)/(.*)', function($auth,$data) {
  $csrf = new CSRF_Protect();
  $csrf->verifyRequest($auth);
  //$data = hdev_data::decd($data);
   $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'TCPDF-main'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'tcpdf_config.php';
  include $regd;  
  $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'TCPDF-main'.DIRECTORY_SEPARATOR.'tcpdf.php';
  include $regd; 
  //$var1 = explode("-", $data);
  $var1 = urldecode($data);
  //print_r($var1); exit();
  $tg = array("type"=>"ii","report"=>"kjhkasd");
  //echo(json_encode($tg));
  $var1 = json_decode($var1);
  //var_dump($var1);
  switch ($var1->type) {
    case 'admin':
      switch (trim($var1->report)) {
        case 'sales':
           // echo "1";
          $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'report'.DIRECTORY_SEPARATOR.'sales_report.php';
          include $regd; 
          break;
        case 'payments':
          $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'report'.DIRECTORY_SEPARATOR.'land_lord_payments.php';
          include $regd;
          break;
        default:
          // code...
          break;
      }
      break;
    case 'land_lord':
      switch (trim($var1->report)) {
        case 'income':
           // echo "1";
          $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'report'.DIRECTORY_SEPARATOR.'land_lord_income.php';
          include $regd; 
          break;
        case 'payments':
          $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'report'.DIRECTORY_SEPARATOR.'land_lord_payments.php';
          include $regd;
          break;
        default:
          // code...
          break;
      }
      break;    
    default:
      // code...
      break;
  }
  exit();
  //$csrf->up_tk();
  hdev_log::close();
});
hdev_route::add('/app/setting/(.*)/(.*)', function($auth,$data) {
  $csrf = new CSRF_Protect();
  $csrf->verifyRequest($auth);
  $data = hdev_data::decd($data);
  $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'setting.php';
  include $regd;
  //$csrf->up_tk();
  hdev_log::close();
});
//add login page
hdev_route::add('/login', function() {
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::get_url_host());exit();
  }
  include getcwd().'/hdev_c/l_header.php';
  include getcwd().'/hdev_c/re_log_auth.php';
  include getcwd().'/hdev_c/l_footer.php';
  exit();
});
hdev_route::add('/register', function() {
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::get_url_host());exit();
  }
  include getcwd().'/hdev_c/l_header.php';
  include getcwd().'/hdev_c/re_reg_auth.php';
  include getcwd().'/hdev_c/l_footer.php';
  exit();
});

hdev_route::add('/all_mn', function() {
  include get_menu();
  exit();
});
// Add base route (startpage)
hdev_route::add('/', function() {
  //  if (!hdev_log::loged()) {
  //  hdev_note::redirect(hdev_url::get_url_host()."/login");exit();
  //}else{
    hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
  //}
});

//full home page 
hdev_route::add('', function() {
  //if (!hdev_log::loged()) {
  //  hdev_note::redirect(hdev_url::get_url_host()."/login");exit();
  //}else{
    hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
  //}
});
//full home page 
hdev_route::add('/a/b/c', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]); 
  include mini_loader();
  exit();
});
//full home page  
hdev_route::add('/r/about', function() {
  hdev_menu_url::body([hdev_lang::on("menu","about"),"about","/r/about"]);
});
//full home page 
hdev_route::add('/r/home', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
});

hdev_route::add('/r/home/a/b/c', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]); 
  include mini_loader();
  exit();
});
hdev_route::add('/r/profile', function() { 
  $sc = hdev_log::fid();
  switch ($sc) {
    case 'admin':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/profile","/r/profile"]);
      break;
    case 'member':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/member_profile","/r/profile"]);
      break;
    case 'agent':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/agent_profile","/r/profile"]);
      break;
    case 'tenant':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/tenant_profile","/r/profile"]);
      break;      
    default:
      hdev_menu_url::body(["404","error","/error"]);
      break;
  }
});
hdev_route::add('/r/profile/a/b/c', function() { 
  $sc = hdev_log::fid();
  switch ($sc) {
    case 'admin':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/profile","/r/profile"]);
      break;
    case 'member':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/member_profile","/r/profile"]);
      break;
    case 'agent':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/agent_profile","/r/profile"]);
      break;
    case 'tenant':
      hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/tenant_profile","/r/profile"]);
      break;      
    default:
      hdev_menu_url::body(["404","error","/error"]);
      break;
  }
  include mini_loader();
  exit();
});
hdev_route::add('/r/memb_reg', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/member_reg","/r/memb_reg"]);
});
hdev_route::add('/r/memb_reg/a/b/c', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","member_info"),"hdev_c/dest/member_reg","/r/memb_reg"]);
  include mini_loader();
  exit();
});

hdev_route::add('/child/reg', function() { 
  hdev_menu_url::body(["Children Info","hdev_c/dest/reg_child","/child/reg"]);
});
hdev_route::add('/child/reg/a/b/c', function() { 
  hdev_menu_url::body(["Children Info","hdev_c/dest/reg_child","/child/reg"]);
  include mini_loader();
  exit();
});

hdev_route::add('/request/child', function() { 
  hdev_menu_url::body(["Children request Info","hdev_c/dest/request_child","/request/child"]);
});
hdev_route::add('/request/child/a/b/c', function() { 
  hdev_menu_url::body(["Children request Info","hdev_c/dest/request_child","/request/child"]);
  include mini_loader();
  exit();
});
hdev_route::add('/child/request', function() { 
  hdev_menu_url::body(["Children requested Info","hdev_c/dest/child_request_admin","/child/request"]);
});
hdev_route::add('/child/request/a/b/c', function() { 
  hdev_menu_url::body(["Children requested Info","hdev_c/dest/child_request_admin","/child/request"]);
  include mini_loader();
  exit();
});
hdev_route::add('/child/approve', function() { 
  hdev_menu_url::body(["Approved Children requested Info","hdev_c/dest/child_request_approve","/child/approve"]);
});
hdev_route::add('/child/approve/a/b/c', function() { 
  hdev_menu_url::body(["Approved Children requested Info","hdev_c/dest/child_request_approve","/child/approve"]);
  include mini_loader();
  exit();
});

hdev_route::add('/child/reject', function() { 
  hdev_menu_url::body(["Rejecte Children requested Info","hdev_c/dest/child_request_reject","/child/reject"]);
});
hdev_route::add('/child/reject/a/b/c', function() { 
  hdev_menu_url::body(["Rejecte Children requested Info","hdev_c/dest/child_request_reject","/child/reject"]);
  include mini_loader();
  exit();
});
hdev_route::add('/list/transfer', function() { 
  hdev_menu_url::body(["Rejecte Children available for being transfered","hdev_c/dest/children_grant_list","/list/transfer"]);
});
hdev_route::add('/list/transfer/a/b/c', function() { 
  hdev_menu_url::body(["Rejecte Children available for being transfered","hdev_c/dest/children_grant_list","/list/transfer"]);
  include mini_loader();
  exit();
});
hdev_route::add('/child/delete', function() { 
  hdev_menu_url::body(["Deleted Children info","hdev_c/dest/deleted_child","/child/delete"]);
});
hdev_route::add('/child/delete/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Children info","hdev_c/dest/deleted_child","/child/delete"]);
  include mini_loader();
  exit();
});

hdev_route::add('/center/reg', function() { 
  hdev_menu_url::body(["Collection Centers Info","hdev_c/dest/reg_center","/center/reg"]);
});
hdev_route::add('/center/reg/a/b/c', function() { 
  hdev_menu_url::body(["Collection Centers Info","hdev_c/dest/reg_center","/center/reg"]);
  include mini_loader();
  exit();
});
hdev_route::add('/center/deleted', function() { 
  hdev_menu_url::body(["Deleted Collection Centers Info","hdev_c/dest/deleted_center","/center/deleted"]);
});
hdev_route::add('/center/deleted/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Collection Centers Info","hdev_c/dest/deleted_center","/center/deleted"]);
  include mini_loader();
  exit();
});
hdev_route::add('/sponsor/reg', function() { 
  hdev_menu_url::body(["Sponsor Info","hdev_c/dest/reg_sponsor","/sponsor/reg"]);
});
hdev_route::add('/sponsor/reg/a/b/c', function() { 
  hdev_menu_url::body(["Sponsor Info","hdev_c/dest/reg_sponsor","/sponsor/reg"]);
  include mini_loader();
  exit();
});
hdev_route::add('/sponsor/deleted', function() { 
  hdev_menu_url::body(["Deleted Sponsors","hdev_c/dest/deleted_sponsor","/sponsor/deleted"]);
});
hdev_route::add('/sponsor/deleted/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Sponsors","hdev_c/dest/deleted_sponsor","/sponsor/deleted"]);
  include mini_loader();
  exit();
});

hdev_route::add('/sponsor/approve', function() { 
  hdev_menu_url::body(["sponsors Registration Requests","hdev_c/dest/approve_sponsor","/sponsor/approve"]);
});
hdev_route::add('/sponsor/approve/a/b/c', function() { 
  hdev_menu_url::body(["sponsors Registration Requests","hdev_c/dest/approve_sponsor","/sponsor/approve"]);
  include mini_loader();
  exit();
});
hdev_route::add('/sponsor/reject', function() { 
  hdev_menu_url::body(["Rejected Sponsors Registration requests","hdev_c/dest/reject_sponsor","/sponsor/reject"]);
});
hdev_route::add('/sponsor/reject/a/b/c', function() { 
  hdev_menu_url::body(["Rejected Sponsors Registration requests","hdev_c/dest/reject_sponsor","/sponsor/reject"]);
  include mini_loader();
  exit();
});
hdev_route::add('/s.js', function() {
  if (hdev_log::loged()) {
    //include 'executor/main_app_js.php';
    include 'executor/main_app_js_2.php';
  }
  hdev_log::close();
});

hdev_route::add('/gen.js', function() {
  if (hdev_log::loged()) {
    include 'executor/main_app_js.php';
  }
  hdev_log::close();
});

hdev_route::add('/script-1', function() {
    include 'hdev_c/main_app_js.php';
    exit;
});

hdev_route::add('/auth/gen/(.*)', function($er_rasms_qqrrccdd) {
  if (hdev_log::loged()) {
    include 'executor/cds.php';
  }
  hdev_log::close();
});
hdev_route::add('/test', function() {
  include 'hdev_c/test.php';
  exit();
});


///********************************backups****************************


// Add a 404 not found route
hdev_route::pathNotFound(function($path) { 
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 404 Not Allowed');
  hdev_menu_url::body(["error","hdev_c/error","/error"]);
});
 
// Add a 405 method not allowed route
hdev_route::methodNotAllowed(function($path, $method) {
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 405 Method Not Allowed');
  echo 'Error 405 :-(<br>';
  echo 'The requested path "'.$path.'" exists. But the request method "'.$method.'" is not allowed on this path!';
});

// Run the Router with the given Basepath
// If your script lives in the web root folder use a / or leave it empty
//hdev_route::unset_r(2);// remove a route

//var_export(hdev_route::all_req());exit;// all requests
/*$tg = array();
$reqs = hdev_route::all_req();
foreach ($reqs as $key => $value) {
  $tg[$value['expression']] = ['name'=>'','func'=>''];
} 
var_export($tg);
exit();*/
hdev_route::access('/');
//hdev_route::run('/'); 
//hdev_route::access('/', false, false, false, "http://o.rasms/r/profile_info");
//exit(hdev_route::get_active2());

//var_export(parse_url(hdev_url::menu(ltrim($_SERVER['REQUEST_URI'],'/'))));exit;
//echo hdev_route::get_active();
$rasms_stc = new hdev_url_service('',trim(hdev_route::get_active()));
//echo hdev_route::get_active();
//echo hdev_route::get_active2();exit();
//var_dump(hdev_route::get_active());
//var_dump($rasms_stc->error('alert'));exit();
//var_dump($rasms_stc->access());exit();
if ($rasms_stc->access()) {
  /// access granted
  //echo "granted";
  $rt = new hdev_db("default"); 
  if ($rt->connection_check()) {
    //var_dump($rt->connection_check());exit;
  }else {
    echo "<div style='width: 50%;margin-left:15%;margin-top:5%;'><fieldset>RASMS DATA STORE CHECKER<hr>Re-start the application to get this fixed <br> Or click <a href='".hdev_url::menu("")."'>Here</a><hr>&copy".date("Y")."- IZERE HIRWA ROGER - ".APP_NAME."<hr></fieldset><div>";
    echo '<meta content="2; '.hdev_url::menu("").'" http-equiv="refresh" />'; exit();
  }
    hdev_route::run('/'); 
}else{
  hdev_route::access('/', false, false, false, hdev_url::get_url_full());
  $tt = hdev_route::get_active2();
  if ($tt != "error") {
    hdev_note::message("access denied to request this page");
    $rasms_access_error = $rasms_stc->error('alert');
    hdev_menu_url::body(["Access denied !","error","/error"]);
  }else{
    hdev_menu_url::body(["404","error","/error"]);
  }
  
  ///call custom user func
}
/*foreach (hdev_route::all_req() as $url) {
  echo "\t'".$url['expression']."' => array ("."\n"."\t\t'name' => 'access to view [".$url['expression']."]',\n\t\t'error' => 'You can not access this page',\n\t\t),\n";
  //echo "\t\t\t'".$url['expression']."',\n";
}exit();*/


// If your script lives in a subfolder you can use the following example
// Do not forget to edit the basepath in .htaccess if you are on apache
// hdev_route::run('/api/v1');

// Enable case sensitive mode, trailing slashes and multi match mode by setting the params to true
// hdev_route::run('/', true, true, true);

//authenticate bro
if (!hdev_log::loged()) {
  //hdev_note::message("You must Log in first To access Rasms system");
  //hdev_note::redirect(hdev_url::get_url_host()."/login");
}





////

//$js_controller="og";

?>