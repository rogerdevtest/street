<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Chidren available for being transfered</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <H2>Sponsor request Info</H2>
                  <table id="rasms_all_tables4"  class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Sponsor Reg No.</th>
                      <th>Sponsor Type</th>
                      <th>Sponsor name</th>
                      <th>Sponsor NID/TIN</th>
                      <th>Number of children rquested</th>
                      <th>Number of children Received</th>
                      <th>Reg. Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ckb = hdev_data::child_request(hdev_log::cart("val"),['data']);
                      $ck[] = $ckb;
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:approve_request;id:".$group['cr_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);  
                      $build3 = "ref:reject_request;id:".$group['cr_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject2 = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build3); 

                      $sponsor = hdev_data::sponsor($group['sp_id'],["data"]);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["cr_id"]; ?>
                      </td>
                      <td class="table-plus">
                        <?php echo $group["sp_id"]; ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo hdev_data::sponsor_type($sponsor["sp_type"]); ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo $sponsor["sp_name"]; ?>
                      </td> 
                      <td class="table-plus">
                        <?php echo $sponsor["sp_nid"]; ?>
                      </td>                                          
                      <td>
                        <?php echo $group['cr_num']; ?> Children
                      </td>
                      <td>
                        0
                      </td>
                      <td>
                        <?php echo $group['cr_reg_date']; ?>
                      </td>                 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
                <hr>
                <h2>Available Children</h2>
                <hr>
                  <table data-order='[[ 0, "desc" ]]' id="rasms_all_tables" class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Center</th>
                      <th>Name</th>
                      <th>N.id</th>
                      <th>Sex</th>
                      <th>Birh Date</th>
                      <th>Reg. Date</th>
                      <?php if (hdev_data::service("delete_child") || hdev_data::service("delete_animal")): ?>
                      <th>Action</th>
                      <?php endif ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::child("",['available']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:delete_child;id:".$group['ch_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);                     

                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["ch_id"]; ?>
                      </td>
                      <td>
                        <?php $center = hdev_data::center($group['cn_id'],['data']); echo "( ".$center['cn_id']." ) ".$center['cn_name']; ?>
                      </td>
                      <td>
                        <?php echo $group['ch_name']; ?>
                      </td>
                      <td>
                        <?php echo $group['ch_nid']; ?>
                      </td>
                      <td>
                        <?php echo $group['ch_sex']; ?>
                      </td> 
                      <td>
                        <?php echo $group['ch_born'] ?>
                      </td>                                         
                      <td>
                        <?php echo $group['ch_reg_date']; ?>
                      </td> 
                      <?php if (hdev_data::service("delete_child") || hdev_data::service('edit_child')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('delete_child')): ?>
                          <button type="button" set_btn='fm_set_clk' e_tit="Are you Sure That You Want to transfer This Child to current sponsor?" ref_id="<?php echo $group['ch_id']; ?>" data="<?php echo $reject; ?>" hash="<?php echo $tkn; ?>" rel="external" class="btn btn-success fm_pre_set" data-toggle="modal" data-target=".modal-set" ><i class="fa fa-check-circle"></i> Transfer to this sponsor</button>

                           <?php endif ?>                        
                        </div>
                      </td>
                      <?php endif ?>                   
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('child_reg')): ?>
<div class="modal fade modal-reg"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">New Child Registration</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="child_reg">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="child_reg">  
            <div class="form-group">
              <label for="ch_name">
                Child collection center :
              </label>
              <div class="input-group mb-3">
                <select type="text" class="form-control" name="cn_id" id="cn_id">
                  <option value="">Sellect Collection center</option>
                  <?php foreach (hdev_data::center() as $center) {
                  ?>
                  <option value="<?php echo $center['cn_id'] ?>"><?php echo "( ".$center['cn_id']." ) ".$center['cn_name']; ?></option>
                  <?php
                  } ?>
                </select>
              </div>
            </div>                    
            <div class="form-group">
              <label for="ch_name">
                Child Name :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="ch_name" id="ch_name" placeholder="Child Name">
              </div>
            </div>
            <div class="form-group">
              <label for="ch_nid">
                Child Nid. :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="ch_nid" id="ch_nid" placeholder="Child Nid.">
              </div>
            </div> 
            <div class="form-group">
              <label for="ch_sex">
                Child sex :
              </label>
              <div class="input-group mb-3">
                <select class="form-control" name="ch_sex" id="ch_sex">
                  <option value="">Select sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="ch_born">
                Child Birth date :
              </label>
              <div class="input-group mb-3">
                <input type="date" class="form-control" name="ch_born" id="ch_born" placeholder="Child Birth date">
              </div>
            </div>         
            <div class="form-group">
              <label for="ch_desc">
                Child Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="ch_desc" id="ch_desc" placeholder="Child Description"></textarea>
              </div>
            </div>           
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="child_reg_btn" onclick="fm_submit('child_reg_btn','child_reg');"><i class="fa fa-save"></i> Add New Child</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('edit_child')): ?>
<div class="modal fade modal-edit"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Modify Child info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="edit_child">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" value="" name="ch_id" id="ch_id">
              <input type="hidden" name="ref" value="edit_child">  
            <div class="form-group">
              <label for="ch_name">
                Child collection center :
              </label>
              <div class="input-group mb-3">
                <select type="text" class="form-control" name="cn_id" id="cn_id">
                  <option value="">Sellect Collection center</option>
                  <?php foreach (hdev_data::center() as $center) {
                  ?>
                  <option value="<?php echo $center['cn_id'] ?>"><?php echo "( ".$center['cn_id']." ) ".$center['cn_name']; ?></option>
                  <?php
                  } ?>
                </select>
              </div>
            </div>                    
            <div class="form-group">
              <label for="ch_name">
                Child Name :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="ch_name" id="ch_name" placeholder="Child Name">
              </div>
            </div>
            <div class="form-group">
              <label for="ch_nid">
                Child Nid. :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="ch_nid" id="ch_nid" placeholder="Child Nid.">
              </div>
            </div> 
            <div class="form-group">
              <label for="ch_sex">
                Child sex :
              </label>
              <div class="input-group mb-3">
                <select class="form-control" name="ch_sex" id="ch_sex">
                  <option value="">Select sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="ch_born">
                Child Birth date :
              </label>
              <div class="input-group mb-3">
                <input type="date" class="form-control" name="ch_born" id="ch_born" placeholder="Child Birth date">
              </div>
            </div>         
            <div class="form-group">
              <label for="ch_desc">
                Child Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="ch_desc" id="ch_desc" placeholder="Child Description"></textarea>
              </div>
            </div>           
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="edit_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_child_btn" onclick="fm_submit('edit_child_btn','edit_child');"><i class="fa fa-save"></i> Save Child Info</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>

<?php if (hdev_data::service('delete_child')): ?> 
<div class="modal fade modal-set" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2" id="e_tit"></th>
                </tr>
                <tr>
                  <td>Record id : </td>
                  <td id="ref_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="fm_set_clk" data="" hash="" onclick="fm_app('fm_set_clk')"><i class="fa fa-times-circle"></i> </button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>