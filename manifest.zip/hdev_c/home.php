<?php if (1==5 || !hdev_log::loged()): ?>
<div id="app_data" align="center">
      <div class="card-body" style="background: transparent !important;">
        <div class="col-sm-12" style="vertical-align: center;height: 300px;text-align: center;" align="center">
          <?php if (hdev_log::loged()): ?>
              <h1 class="text-xl">
                <?php echo hdev_lang::on('data','welcome'); ?> <?php echo hdev_data::active_user("fid"); ?> : 
              </h1><br>
              <h1 class="text-xl text-success" style="text-transform: capitalize;"><?php echo hdev_data::active_user("name"); ?></h1>


          <?php else: ?> 
            <a href="<?php echo hdev_url::menu('login'); ?>" class="btn btn-primary btn-xl p-5" ext_link="ok">
              <span class="fa fa-unlock"></span>
              <?php echo hdev_lang::on('form','signin'); ?>
            </a>
          <?php endif ?>
        </div>
      </div>
      <div class="card-footer">
      </div>
  </div>
</div>
<?php endif ?>
<?php if (hdev_log::loged()): ?>
<div id="app_data">
  <h1>Welcome</h1>
</div>
<?php endif ?>