<?php 
	$rasms_urls = array ( 
	'/script-1' => array (
		'name' => 'access to view /script-1',
		'error' => 'You can not access this menu page',
		),		
	'/all_mn' => array (
		'name' => 'access to view /all_mn',
		'error' => 'You can not access this menu page',
		),
	'/login_i' => array (
		'name' => 'access to view [/login_i]',
		'error' => 'You can not access this page',
		),
	'/up' => array (
		'name' => 'access to view [/up]',
		'error' => 'You can not access this page',
		),
	'/app/setting/(.*)/(.*)' => array (
		'name' => 'access to view [/app/setting/(.*)/(.*)]',
		'error' => 'You can not access this page',
		),
	'/login' => array (
		'name' => 'access to view [/login]',
		'error' => 'You can not access this page',
		),
	'/register' => array (
		'name' => 'access to view [/register]',
		'error' => 'You can not access this page',
		),
	'/' => array (
		'name' => 'access to view [/]',
		'error' => 'You can not access this page',
		),
	'/a/b/c' => array (
		'name' => 'access to view [/]',
		'error' => 'You can not access this page',
		),	
	'' => array (
		'name' => 'access to view []',
		'error' => 'You can not access this page',
		),
	'/r/about' => array (
		'name' => 'access to view [/r/about]',
		'error' => 'You can not access this page',
		),
	'/r/home' => array (
		'name' => 'access to view [/r/home]',
		'error' => 'You can not access this page',
		),
	'/r/home/a/b/c' => array (
		'name' => 'access to view [/r/home/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/home/page/(.*)/a/b/c' => array (
		'name' => 'access to view [/r/home/page/(.*)/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/home/page/(.*)' => array (
		'name' => 'access to view [/r/home/page/(.*)]',
		'error' => 'You can not access this page',
		),
	'/r/profile' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/r/profile/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/child/reg' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/child/reg/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/child/delete' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/child/delete/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/center/reg' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/center/reg/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/center/deleted' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/center/deleted/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/sponsor/reg' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/sponsor/reg/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/sponsor/deleted' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/sponsor/deleted/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/sponsor/approve' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/approve/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/reject' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/reject/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/request/child' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/request/child/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/child/request' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/child/request/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/child/approve' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/child/approve/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/child/reject' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/child/reject/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/list/transfer' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/list/transfer/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),		
	'/sponsor/child' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/sponsor/child/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/child/(.*)/request' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/child/(.*)/request/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/sponsor/request/child/(.*)/request' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sponsor/request/child/(.*)/request/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/my/child/(.*)/request' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/my/child/(.*)/request/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),											
	);
	//$all_services = array_keys($rasms_urls);
	//$tg = "";
	//foreach ($all_services as $key) {
	//	if ($key == "stud_delete") {
	//		$tg = 9;
	//	}
	//	if ($tg != 9) {
	//		echo "'".$key."' /*".$rasms_urls[$key]['name']."*/,\n";
	//	}
		
	//}
	$rasms_urls_users = array(
		'guest'=>array(
			'/all_mn',
			'/register' /*Access to login*/,
			'/login' /*Access to login*/,
			'/login_i' /*Access To view Login Page*/,
			'/up' /*Access to submit data*/,
			'/login_i',
			'/r/house_view/(.*)/a/b/c' /*Access to submit data*/,
			'/r/house_view/(.*)',
			'',
			'/',
			'/r/home' /*Access to view homepage*/,
			'/r/home/a/b/c' /*Access to view homepage*/,
			'/r/home/page/(.*)' /*Access to view homepage*/,
			'/r/home/page/(.*)/a/b/c' /*Access to view homepage*/,
			'/script-1' /*Access to test*/,
		),
		'admin'=> array( /// was admin
			'/all_mn',
			'/gen.js',
			'/s.js',
			'/r/memb_reg',
			'/r/memb_reg/a/b/c',
			'/login_i',
			'/up',
			'/app/setting/(.*)/(.*)',
			'/login',
			'/register',
			'/',
			'/a/b/c',
			'',
			'/r/about',
			'/r/home',
			'/r/home/a/b/c',
			'/r/home/page/(.*)/a/b/c',
			'/r/home/page/(.*)',
			'/r/profile',
			'/r/profile/a/b/c',
			"/script-1",
			"/child/reg",
			"/child/reg/a/b/c",
			"/child/delete",
			"/child/delete/a/b/c",			
			"/center/reg",
			"/center/reg/a/b/c",
			"/center/deleted",
			"/center/deleted/a/b/c",			
			"/sponsor/reg",
			"/sponsor/reg/a/b/c",
			"/sponsor/deleted",
			"/sponsor/deleted/a/b/c",
			"/sponsor/approve",
			"/sponsor/approve/a/b/c",
			"/sponsor/reject",
			"/sponsor/reject/a/b/c",
			'/child/request',
			'/child/request/a/b/c',
			"/child/approve",
			"/child/approve/a/b/c",
			"/child/reject",
			"/child/reject/a/b/c",
			"/list/transfer",
			"/list/transfer/a/b/c",	
			"/sponsor/child",
			"/sponsor/child/a/b/c",
			"/sponsor/child/(.*)/request",
			"/sponsor/child/(.*)/request/a/b/c",
			"/sponsor/request/child/(.*)/request",
			"/sponsor/request/child/(.*)/request/a/b/c",	
		),
		'sponsor'=> array( /// was admin
			'/all_mn',
			'/gen.js',
			'/s.js',
			'/r/memb_reg',
			'/r/memb_reg/a/b/c',
			'/login_i',
			'/up',
			'/app/setting/(.*)/(.*)',
			'/login',
			'/register',
			'/',
			'/a/b/c',
			'',
			'/r/about',
			'/r/home',
			'/r/home/a/b/c',
			'/r/home/page/(.*)/a/b/c',
			'/r/home/page/(.*)',
			'/r/profile',
			'/r/profile/a/b/c',
			"/script-1",
			'/request/child',
			'/request/child/a/b/c',	
			"/my/child/(.*)/request",
			"/my/child/(.*)/request/a/b/c",					
		),
		'agent'=> array( /// was admin
			'/all_mn',
			'/login_i',
			'/up',
			'/app/setting/(.*)/(.*)',
			'/login',
			'/register',
			'/',
			'',
			'/r/about',
			'/r/home',
			'/r/home/a/b/c',
			'/r/home/page/(.*)/a/b/c',
			'/r/home/page/(.*)',
			'/r/profile',
			'/r/profile/a/b/c',
			"/script-1"
			
		),	
	);
	
 ?>