<?php if (1==3): ?>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
    </div>
  </aside>
  <!-- /.control-sidebar --> 
  <div class="loader" align="center">
    <span style="width: auto;text-align: center;"><img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/loading2.gif'));?>" alt="" /><br><i><?php echo hdev_lang::on("form","load"); ?></i></span>
  </div>
<?php endif ?>
  

</div><!-- ./app body -->
<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Powered by <?php echo APP_PROGRAMMER['name'];?>
      <!--Powered by IZERE HIRWA Roger-->
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; - <?php echo date('Y'); ?> <a href="https://free.facebook.com/itizerehirwaroger" target="_blank">Aline</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="<?php echo hdev_url::menu('plugins/jquery/jquery.min.js'); ?>"></script>
<?php if (1==1): ?>
<!-- Bootstrap 4 -->
<script src="<?php echo hdev_url::menu('plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <!-- pace-progress -->
<script src="<?php echo hdev_url::menu('plugins/pace-progress/pace.min.js'); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo hdev_url::menu('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js'); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo hdev_url::menu('dist/js/adminlte.min.js'); ?>"></script>
<script src="<?php echo hdev_url::menu('plugins/Smoothproducts/js/jquery-2.1.3.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/Smoothproducts/js/smoothproducts.js?h='.rand());?>"></script>
<!-- AdminLTE for demo purposes -->
<!--<script src="<?php echo hdev_url::menu('dist/js/demo.js'); ?>"></script>-->
<!-- DataTables  & Plugins -->
<script src="<?php echo hdev_url::menu("plugins/datatables/jquery.dataTables.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-responsive/js/dataTables.responsive.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-responsive/js/responsive.bootstrap4.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-buttons/js/dataTables.buttons.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-buttons/js/buttons.bootstrap4.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-fixedcolumns/js/dataTables.fixedColumns.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/jszip/jszip.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/pdfmake/pdfmake.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/pdfmake/vfs_fonts.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-buttons/js/buttons.html5.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-buttons/js/buttons.print.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-buttons/js/buttons.colVis.min.js"); ?>"></script>
<!-- BS-Stepper -->
<script src="<?php echo hdev_url::menu('plugins/bs-stepper/js/bs-stepper.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/ajax/sl.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/ajax/former.js');?>"></script>
<!--<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>-->
<script type="text/javascript">
/*function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}*/
</script>
<?php endif ?>
<!--<script src="<?php echo hdev_url::menu('gen.js?v='.rand());?>"></script>
<script src="<?php echo hdev_url::menu('s.js?v='.rand());?>" defer></script>
<script type="text/javascript">
  //$("#app_menu").load("<?php echo hdev_url::menu('all_mn') ?>");
</script>-->
<script type="text/javascript">
  function logout(ur = '') {
    var confim = window.confirm('<?php echo hdev_lang::on('validation','confirm_logout'); ?>');
    if (confim) {
      window.location.href=ur;
    }
  }
    var $load_status= '<span><i class="fa fa-spinner fa-spin"></i></span><i>&nbsp;&nbsp;wait...!!!</i>';
    function fm_submit(btn_ck,fm_ck,url_action='') {
      //alert('hello');
        var formData = jQuery('#'+fm_ck).serialize();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.wait').html($load_status);
                $('#'+btn_ck).hide();
               },
              success:function(html){
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#'+btn_ck).show();
                  }, 4000);
              },
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                $('#'+btn_ck).show();
              }
            });
    }
      function fm_app(fm_btn) {
      var dtt = $('#'+fm_btn).attr("data");
      var hss = $('#'+fm_btn).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#'+fm_btn).hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#'+fm_btn).show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#'+fm_btn).show();
            }
          });
        return false;
    }
  function id_validator(val_text='',input_icon='',message_box='',sub_btn='') {

    if (val_text.length != 16) {
      errors = "Id must be 16 digits";
      var a = '<span class="text-danger">'+errors+'</span>';
      $(sub_btn).hide();
      $(message_box).html(a);
      $(input_icon).html('<span class="fa fa-times-circle text-danger"></span>');
    }else{
      $(sub_btn).show();
      $(message_box).html('');
      $(input_icon).html('<span class="fa fa-check-circle text-success"></span>');
    }
  }
  function mr_step(calll,val=1) {
    var stepper = new Stepper($('.bs-stepper')[0]);
    if (calll == "next") {
      for (var i = 1; i <= val; i++) {
        stepper.next();
      }
    }
    if (calll == "previous") {
      for (var i = 1; i <= val; i++) {
        stepper.previous();
      }
    }
  }
  function mr_locator(ret='',prov_v="",dist_v="",sect_v="",cel_v="") {
    
      var cv = '<?php $csrf = new CSRF_Protect();echo $csrf->getToken();  ?>';
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'location_select',type:ret,prov:prov_v,dist:dist_v,sect:sect_v,cell:cel_v,cover:cv},
        beforeSend: function(){

          var icoo = $('#'+ret).attr(ret+"-ico");
          $('#'+ret+' input-group-text').html('<div class="process-loader"></div>');
             },
            success:function(html){
              //alert(html);
              var icoo = $('#'+ret).attr(ret+"-ico");
              $('#'+ret+' input-group-text').html('<span class="'+icoo+'" ></span>');
              switch(ret) {
                case 'district':
                  $('#'+ret).html(html); 
                  $('#sector').html('<option value="">---Select---</option>');
                  $('#cell').html('<option value="">---Select---</option>'); 
                  $('#village').html('<option value="">---Select---</option>');
                  break;
                case 'sector':
                  $('#'+ret).html(html); 
                  $('#cell').html('<option value="">---Select---</option>'); 
                  $('#village').html('<option value="">---Select---</option>');
                  break;
                case 'cell':
                  $('#'+ret).html(html); 
                  $('#village').html('<option value="">---Select---</option>'); 
                  break; 
                case 'village':
                  $('#'+ret).html(html); 
                  break;   
              }
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      })
  }
  function call_stepper() {
    // As a jQuery Plugin
    var step_var = $('.bs-stepper').attr('step_val');
    if(step_var == "ok") {
      $(document).ready(function () {
      var stepper = new Stepper($('.bs-stepper')[0]);
    });
    }
    
  }
  //sm_nt();
  function update_datatable() {
    $('.wait').addClass('bg-white');
      //window.stepper = new Stepper(document.querySelector('.bs-stepper'));
    $(document).ready(function() {
      $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        lazyLoad: true,
        lazyLoadEager: 1,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: true
          },
          600: {
            items: 3,
            nav: true
          },
          1000: {
            items: 4,
            nav: true,
            loop: true,
            margin: 10
          }
        }
      })
    });

  $("#rasms_all_tables").DataTable({
    "language": {
            "url": "<?php echo hdev_url::menu('dist/'.hdev_lang::get_lang().'.json'); ?>"
        },
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "buttons": ["copy", "csv", "excel", "pdf", "print"]
  }).buttons().container().appendTo('#rasms_all_tables_wrapper .col-md-6:eq(0)');
  $("#rasms_all_tables4").DataTable({
    "language": {
            "url": "<?php echo hdev_url::menu('dist/'.hdev_lang::get_lang().'.json'); ?>"
        },
    "responsive": true, "lengthChange": false, "autoWidth": false,"paging":false,"searching":false
  });  
  $("#rasms_rep_tables").DataTable({
    "language": {
            "url": "<?php echo hdev_url::menu('dist/'.hdev_lang::get_lang().'.json'); ?>"
        },
    "responsive": false, "lengthChange": false, "autoWidth": false,'paging':false,
    "buttons": ["copy", "csv", "excel", "pdf", "print"]
  }).buttons().container().appendTo('#rasms_rep_tables_wrapper .col-md-6:eq(0)');    
  $("#rasms_all_tables2").DataTable({
    "language": {
            "url": "<?php echo hdev_url::menu('dist/'.hdev_lang::get_lang().'.json'); ?>"
        },
    "responsive": true, "lengthChange": false, "autoWidth": true,
    "buttons": [""]
  });  
  call_stepper();
}
  function attach(cur='') {
    //alert(cur);
    if (cur == "") {
      cur = window.location.href;
    }
    $('#menu_loader').html('<div class="process-loader"></div>');
    var rest =  cur.split("?");
     xhttp = new XMLHttpRequest();
     xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
          if (this.status == 200) {
            $('body #app_body').html(this.responseText);
            $('#menu_loader').html('<!--loader-->');
            update_datatable();
          }
          if (this.status == 404) {
            //window.location.reload();
          }
        }
      }
      xhttp.open("GET", ""+rest[0]+"/a/b/c", true);
      xhttp.send();
  }
    var $load_status= '<span><i class="fa fa-spinner fa-spin"></i></span><i>&nbsp;&nbsp;wait...!!!</i>';
    function fm_submit(btn_ck,fm_ck,url_action='') {
      //alert('hello');
        var formData = jQuery('#'+fm_ck).serialize();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.wait').html($load_status);
                $('#'+btn_ck).hide();
               },
              success:function(html){
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#'+btn_ck).show();
                  }, 4000);
              },
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                $('#'+btn_ck).show();
              }
            });
    }
  $load_status= $('<span><img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/loading2.gif'));?>"/></span><i>&nbsp;&nbsp;<?php echo hdev_lang::on("validation","processing"); ?>...!!!</i>');
  $saved = $('<span class="text-success"><?php echo hdev_lang::on("validation","saved"); ?></span>');
  $min_wait = $('<span class="text-success"><?php echo hdev_lang::on("validation","loading"); ?></span>');
 $(document).ready(function(){ 
  update_datatable();

    $(document).on('click','.fm_pre_set',function(e) {

      //alert('helloooo');
      var ref_id=$(this).attr("ref_id");
      var e_tit=$(this).attr("e_tit");
      var m_dt=$(this).html();
      var set_btn = $(this).attr('set_btn');
      var precls = $(this).attr('class');

      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");

      $('.modal-set #ref_id').html(ref_id);
      $('.modal-set #e_tit').html(e_tit);

      $('.modal-set #'+set_btn).attr("data","");
      $('.modal-set #'+set_btn).attr("hash","");      
      $('.modal-set #'+set_btn).attr("data",dt);
      $('.modal-set #'+set_btn).attr("hash",hs);
      $('.modal-set #'+set_btn).html(m_dt);
      $('.modal-set #'+set_btn).attr('class',precls);
      $('.modal-set #'+set_btn).removeClass('fm_pre_set');
      //alert(dt);
    }); 

    $(document).on('click','.pager_control',function(e) {
        var urr=$(this).attr("url");
        var pgg=$(this).attr("page");
        var lcc = urr+'/'+pgg;
        attach(lcc);
    });        
    <?php if (hdev_data::service('agent_reg')): ?> 
    $(document).on('click','#reg_agent',function(e) {
      e.preventDefault();
      var formData = jQuery('#agent_reg').serialize();
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('up');?>",
            data: formData,
            beforeSend: function(){
              $('.wait').html($load_status);
              $('#reg_agent').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#reg_agent').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#reg_agent').show();
            }
          });
        return false; 
    }); 
    <?php endif ?>  
  <?php if (hdev_data::service('edit_center')): ?> 
    $(document).on('click','.edit_cent_btn',function(e) {
      var cn_name=$(this).attr("cn_name");
      var cn_location=$(this).attr("cn_location");
      var cn_tel=$(this).attr("cn_tel");
      var cn_username=$(this).attr("cn_username");
      var cn_id=$(this).attr("cn_id");

      $('.modal-edit #cn_name').val(cn_name);
      $('.modal-edit #cn_location').val(cn_location);
      $('.modal-edit #cn_tel').val(cn_tel);
      $('.modal-edit #cn_username').val(cn_username);
      $('.modal-edit #cn_id').val(cn_id);
    }); 
    <?php endif ?>
  <?php if (hdev_data::service('edit_child')): ?> 
    $(document).on('click','.edit_chid_btn',function(e) {
      var ch_id=$(this).attr("ch_id");
      var cn_id=$(this).attr("cn_id");
      var ch_name=$(this).attr("ch_name");
      var ch_nid=$(this).attr("ch_nid");
      var ch_sex=$(this).attr("ch_sex");
      var ch_born=$(this).attr("ch_born");
      var ch_desc=$(this).attr("ch_desc");

      $('.modal-edit #ch_id').val(ch_id);
      $('.modal-edit #cn_id').val(cn_id);
      $('.modal-edit #ch_name').val(ch_name);
      $('.modal-edit #ch_nid').val(ch_nid);
      $('.modal-edit #ch_sex').val(ch_sex);
      $('.modal-edit #ch_born').val(ch_born);
      $('.modal-edit #ch_desc').val(ch_desc);
    }); 
    <?php endif ?>      
  <?php if (hdev_data::service('edit_sponsor')): ?> 
    $(document).on('click','.edit_sp_btn',function(e) {
      var sp_id=$(this).attr("sp_id");
      var sp_type=$(this).attr("sp_type");
      var sp_nid=$(this).attr("sp_nid");
      var sp_name=$(this).attr("sp_name");
      var sp_tel=$(this).attr("sp_tel");
      var sp_username=$(this).attr("sp_username");
      var sp_location=$(this).attr("sp_location");
      var sp_desc=$(this).attr("sp_desc");

      $('.modal-edit #sp_id').val(sp_id);
      $('.modal-edit #sp_type').val(sp_type);
      $('.modal-edit #sp_nid').val(sp_nid);
      $('.modal-edit #sp_name').val(sp_name);
      $('.modal-edit #sp_tel').val(sp_tel);
      $('.modal-edit #sp_username').val(sp_username);
      $('.modal-edit #sp_location').val(sp_location);
      $('.modal-edit #sp_desc').val(sp_desc);

    }); 
    <?php endif ?>      
    <?php if (hdev_data::service('agent_delete')): ?> 
    $(document).on('click','.ag_delete',function(e) {
      var agent_name=$(this).attr("name");
      var agent_username=$(this).attr("username");
      var agent_email=$(this).attr("email");
      var agent_group=$(this).attr("group");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #agent_group').html(agent_group);
      $('.modal-delete #agent_name').html(agent_name);
      $('.modal-delete #agent_username').html(agent_username);
      $('.modal-delete #agent_email').html(agent_email);
      $('.modal-delete #agent_delete').attr("data","");
      $('.modal-delete #agent_delete').attr("hash","");      
      $('.modal-delete #agent_delete').attr("data",dt);
      $('.modal-delete #agent_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#agent_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#agent_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#agent_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#agent_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>
  <?php if (hdev_data::service('agent_edit')): ?> 
    $(document).on('click','.ag_edit',function(e) {
      var group=$(this).attr("group");
      var a_id=$(this).attr("a_id");
      var e_t_name=$(this).attr("e_t_name");
      var e_t_nid=$(this).attr("e_t_nid");
      var e_sex=$(this).attr("e_sex");
      var e_t_username=$(this).attr("e_t_username");
      var e_t_tel=$(this).attr("e_t_tel");
      var e_t_email=$(this).attr("e_t_email");
      $('.modal-edit #sg_id').val(group);
      $('.modal-edit #a_id').val(a_id);
      $('.modal-edit #e_t_name').val(e_t_name);
      $('.modal-edit #e_t_nid').val(e_t_nid);
      $('.modal-edit #e_sex').val(e_sex);
      $('.modal-edit #e_t_username').val(e_t_username);
      $('.modal-edit #e_t_tel').val(e_t_tel);
      $('.modal-edit #e_t_email').val(e_t_email);
    }); 
    $(document).on('click','#edit_agent',function(e) {
      e.preventDefault();
      var formData = jQuery('#agent_edit').serialize();
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('up');?>",
            data: formData,
            beforeSend: function(){
              $('.wait').html($load_status);
              $('#edit_agent').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#edit_agent').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#edit_land_lord').show();
            }
          });
        return false; 
    }); 
    <?php endif ?>
    <?php if (hdev_data::service('sales_delete')): ?>  
    $(document).on('submit','#sales_delete',function(e) {  
        e.preventDefault();
      if($('#imgInp2').val()) {

        $(this).ajaxSubmit({  
          target:   '.wait2',  
          beforeSubmit: function() {
            $("#progress-bar2").width('0%');
            $('.wait2').html($load_status);
            $('#delete_sales').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar2").width(percentComplete + '%');
            $("#progress-bar2").html('<div id="progress-status">'+percentComplete+' %</div>');

          },
          success:function (){
              $('#delete_sales').show();

            setTimeout(function(){
              $('.wait2').html('');
            }, 9000);
          },
          resetForm: false
        }); 
        return false; 
      }else{
        a = '<span class="text-danger">Choose what to upload first</span>';
        $('.wait2').html(a);
        setTimeout(function(){
          $('.wait2').html('');
        }, 3000);
        return false;
      }
    });
    <?php endif ?>     
    <?php if (hdev_data::service('user_edit')): ?> 
    $(document).on('click','#edit_user_btn',function(e) {
      e.preventDefault();
      var formData = jQuery('#user_edit').serialize();
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('up');?>",
            data: formData,
            beforeSend: function(){
              $('.wait').html($load_status);
              $('#edit_user_btn').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#edit_user_btn').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#edit_user_btn').show();
            }
          });
        return false; 
    }); 
    <?php endif ?>   
    <?php if (hdev_data::service('self_change_user_pwd')): ?> 
      $(document).on('click','#self_sec_p_btn',function(e) {
          e.preventDefault();
          var formData = jQuery('#self_sec_p').serialize();
          $.ajax({ 
                type: "POST",
                url: "<?php echo hdev_url::menu('up');?>",
                data: formData,
                beforeSend: function(){
                  $('.wait').html($load_status);
                  $('#self_sec_p_btn').hide();
                 },
                success:function(html){
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#self_sec_p_btn').show();
                  }, 4000);
                },
                error: function(){
                  $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                  $('#self_sec_p_btn').show();
                }
              });
          });
      <?php endif ?>
  });

  /*$(function () {
    $("#rasms_all_tables").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#rasms_all_tables_wrapper .col-md-6:eq(0)');
  });*/
</script>
<script src="<?php echo hdev_url::menu('script-1'); ?>"></script>
</body>
</html>
